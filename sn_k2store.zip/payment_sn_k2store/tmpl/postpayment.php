<?php
/**
 * @package     Joomla - > Site and Administrator payment info
 * @subpackage  com_k2store
 * @subpackage 	Trangell_Zarinpal
 * @copyright   trangell team => https://trangell.com
 * @copyright   Copyright (C) 20016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

 defined('_JEXEC') or die('Restricted access'); ?>

<?php if(!empty($vars['onAfterPaymentText'])): ?>
    <div class="note"><?php echo JText::_($vars['onAfterPaymentText']); ?></div>
<?php endif; ?>
