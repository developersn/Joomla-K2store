<?php
defined('_JEXEC') or die('Restricted access');
?>

<?php if(!empty($vars['onSelectionText'])): ?>
    <div class="k2store-on-selection-text">
        <?php echo JText::_($vars['onSelectionText']); ?>
    </div>
<?php endif; ?>