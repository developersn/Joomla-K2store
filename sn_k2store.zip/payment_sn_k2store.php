<?php
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_ADMINISTRATOR.'/components/com_k2store/library/plugins/payment.php');

jimport('sncore.include');

class plgK2StorePayment_sn_k2store extends K2StorePaymentPlugin
{
    var $_element = 'payment_sn_k2store';

    function __construct(&$subject,$config)
    {
        SNGlobal::loadLanguage('plg_k2store_payment_sn_k2store',JPATH_ADMINISTRATOR);

        parent::__construct($subject, $config);
    }

    /* Prepare the payment form before payment */
    function _prePayment($data)
    {
        $displayText = $this->params->get('display_name','پرداخت آنلاین');
        $onBeforePaymentText = $this->params->get('onbeforepayment','');
        $buttonText = $this->params->get('button_text','K2STORE_PLACE_ORDER');
        $pin = $this->params->get('sn_pin','');
        $sendPayerInfo = $this->params->get('sn_send_payer_info',1);
        $currency = $this->params->get('sn_currency',1);

        $email = !empty($data['orderinfo']['email']) ? $data['orderinfo']['email'] : '';
        $email = SNGlobal::filterVar($email,'email','');

        $phone = !empty($data['orderinfo']['phone_2']) ? $data['orderinfo']['phone_2'] : '';
        $phone = SNGlobal::filterVar($phone,'ir_phone','');

        $vars = array(
            'orderId' => (!empty($data['order_id']) ? $data['order_id'] : 0),
            'orderPaymentId' => (!empty($data['orderpayment_id']) ? $data['orderpayment_id'] : 0),
            'amount' => !empty($data['orderpayment_amount']) ? $data['orderpayment_amount'] : 0,
            'email' => $email,
            'phone' => $phone,

            'displayText' => $displayText,
            'onBeforePaymentText' => $onBeforePaymentText,
            'buttonText' => $buttonText,
            'pin' => $pin,
            'currency' => $currency,
            'sendPayerInfo' => $sendPayerInfo,

            'data' => $data,
        );

        $html = $this->_getLayout('prepayment',$vars);
        return $html;
    }

    /* After back from portal */
    function _postPayment($data)
    {
        // Process the payment
        $app = JFactory::getApplication();
        $vars = array();
        $html = '';

        $orderPaymentId = SNGlobal::getVar('orderpayment_id','','int','request');
        $au = SNGlobal::getVar('au','','none','request');
        $urlOrderId = SNGlobal::getVar('order_id','','none','request');
        $sessionData = SNApi::getData();

        if(!empty($orderPaymentId) && !empty($au) && !empty($sessionData) && $sessionData['order_id'] == $urlOrderId)
        {
            // load the orderpayment record and set some values
            JTable::addIncludePath( JPATH_ADMINISTRATOR.'/components/com_k2store/tables' );
            $orderPayment = JTable::getInstance('Orders','Table');
            $orderPayment->load($orderPaymentId);
            $customer_note = $orderPayment->customer_note;

            if($orderPayment->id == $orderPaymentId)
            {

                $bankData = array();
                foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
                {
                    $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
                }

                $data = array (
                    'pin' => $sessionData['pin'],
                    'price' => $sessionData['price'],
                    'order_id' => $sessionData['order_id'],
                    'au' => $au,
                    'bank_return' => $bankData,
                );

                list($status,$msg,$resultData) = SNApi::verify($data,'k2store');
                
                if($status == true)
                {
                    $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;

                    $msg = JText::_('SN_PAID_TRANSACTION');
                    $msg = str_replace('{REF}',$bankAu,$msg);
                    $this->saveStatus($msg,1,$customer_note,'ok',$au,$orderPayment);
                    $app->enqueueMessage('<h5>'.$msg.'</h5>','message');
                    return;
                }
            }
        }

        $msg = JText::_('SN_UNPAID_TRANSACTION');
        $link = JRoute::_(JURI::root(). "index.php?option=com_k2store" );
        $app->redirect($link, '<h5>'.$msg.'</h5>' , $msgType='Error');
    }

    function saveStatus($msg,$statCode,$customer_note,$emptyCart,$trackingCode,$orderpayment)
    {
        $html ='<br />';
        $html .='<strong>'.JText::_('K2STORE_BANK_TRANSFER_INSTRUCTIONS').'</strong>';
        $html .='<br />';
        if (isset($trackingCode))
        {
            $html .= '<br />';
            $html .= 'شماره پیگری : ' . $trackingCode;
            $html .= '<br />';
        }
        $html .='<br />' . $msg;
        $orderpayment->customer_note =$customer_note.$html;
        $payment_status = $this->getPaymentStatus($statCode);
        $orderpayment->transaction_status = $payment_status;
        $orderpayment->order_state = $payment_status;
        $orderpayment->order_state_id = $this->params->get('payment_status', $statCode);

        if ($orderpayment->save())
        {
            if ($emptyCart == 'ok')
            {
                JLoader::register( 'K2StoreHelperCart', JPATH_SITE.'/components/com_k2store/helpers/cart.php');
                K2StoreHelperCart::removeOrderItems( $orderpayment->id );
            }
        }
        else
        {
            $errors[] = $orderpayment->getError();
        }
        if ($statCode == 1){
            require_once (JPATH_SITE.'/components/com_k2store/helpers/orders.php');
            K2StoreOrdersHelper::sendUserEmail($orderpayment->user_id, $orderpayment->order_id, $orderpayment->transaction_status, $orderpayment->order_state, $orderpayment->order_state_id);
        }

        $vars = array();
        $vars['onAfterPaymentText'] = $this->params->get('onafterpayment','');
        $html = $this->_getLayout('postpayment',$vars);
        $html .= $this->_displayArticle();
        return $html;
    }

    /* Before Payment, When Click On Portal */
    function _renderForm($payment_status)
    {
        $onSelectionText = $this->params->get('onselection','');
        $vars = array(
            'onSelectionText' => $onSelectionText,
        );

        $html = $this->_getLayout('form',$vars);
        return $html;
    }

    /* get Payment Status */
    function getPaymentStatus($paymentStatus)
    {
        $status = '';
        switch($paymentStatus)
        {
            case 1:
                $status = JText::_('K2STORE_CONFIRMED');
            break;
            case 3:
                $status = JText::_('K2STORE_FAILED');
            break;
            default:
            case 4:
                $status = JText::_('K2STORE_PENDING');
            break;
        }
        return $status;
    }
}
