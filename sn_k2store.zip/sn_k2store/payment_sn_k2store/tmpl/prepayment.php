<?php
defined('_JEXEC') or die('Restricted access'); 

$vars = isset($vars) ? $vars : array();

$email = $vars['email'];
$phone = $vars['phone'];
$amount = $vars['amount'];
$orderId = $vars['orderId'];
$orderPaymentId = $vars['orderPaymentId'];
$backUrl = JRoute::_(JURI::root(). "index.php?option=com_k2store&view=checkout" ) .'&orderpayment_id='.$orderPaymentId.'&orderpayment_type=payment_sn_k2store&task=confirmPayment' ;

$query = "SELECT * FROM `#__k2store_orders` WHERE `order_id`='".SNGlobal::escape($orderId)."'";
$orderInfo = SNGlobal::selectByQuery($query,2);

$query = "SELECT *FROM `#__k2store_orderitems` WHERE `order_id`='".SNGlobal::escape($orderId)."'";
$dbOrderItems = SNGlobal::selectByQuery($query,1);

$amount = SNApi::modifyPrice($amount,$vars['currency']);

$data = array(
    'pin'=> $vars['pin'],
    'price'=> $amount,
    'callback'=> $backUrl,
    'order_id'=> $orderPaymentId,
    'email'=> $email,
    'mobile'=> $phone,
);

list($status,$msg,$resultData) = SNApi::request($data,$vars['sendPayerInfo'],'k2store');

if($status != true)
{
    echo '<h5 style="color: #bb1111; font-size: 13px;" class="k2store-not-connect">'.$msg.'</h5>';
    die();
}
else
{
    $data['bank_callback_details'] = $resultData['bank_callback_details'];
    $data['au'] = $resultData['au'];

    SNApi::clearData();
    SNApi::setData($data);
}

$formDetails = $resultData['form_details'];

?>
<div class="note">
    <p>
         <strong><?php echo JText::_($vars['onBeforePaymentText']); ?></strong>
    </p>
</div>

<form action="<?php echo $formDetails['action'] ?>" method="<?php echo $formDetails['method'] ?>">
    <?php foreach (!empty($formDetails['fields']) ? $formDetails['fields'] : array() as $key => $value): ?>
        <input type="hidden" name="<?php echo $key; ?>" value="<?php echo $value; ?>" />
    <?php endforeach; ?>
    <input type="submit" class="k2store_cart_button btn btn-primary" value="<?php echo JText::_($vars['buttonText']); ?>" />
</form>