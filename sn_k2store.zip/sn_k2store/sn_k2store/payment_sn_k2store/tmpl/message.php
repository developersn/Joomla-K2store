<?php defined('_JEXEC') or die('Restricted access'); ?>

<div class="note">

	<?php if(!empty($vars['onAfterPaymentText'])): ?>
		<p class="k2store-on-after-payment-message">
			<?php echo $vars['onAfterPaymentText']; ?>
		</p>
	<?php endif; ?>

    <?php if(!empty($vars['message'])): ?>
		<p class="k2store-message">
			<?php echo nl2br($vars['message']); ?>
		</p>
    <?php endif; ?>

</div>