<?php
defined('_JEXEC') or die('Restricted access');

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

if(!defined('DS'))
{
    define('DS',DIRECTORY_SEPARATOR);
}

class plgK2StorePayment_sn_k2storeInstallerScript
{
    function preflight($type,$parent)
    {
        if(!JFolder::exists(JPATH_ADMINISTRATOR .DS. 'components' .DS. 'com_k2store'))
        {
            Jerror::raiseWarning(null,'لطفا ابتدا افزونه کی2 استور را نصب نمایید.');
            return false;
        }
    }

    function postflight($type,$parent)
    {
        /* Enable Plugin */
        $database = JFactory::getDBO();
        $query = "UPDATE `#__extensions` SET `enabled` = 1 WHERE `element` = 'payment_sn_k2store'";
        $database->setQuery($query);
        $database->query();

        /* Move Libraries Files */
        $from = JPATH_ROOT .DS. 'plugins' .DS. 'k2store' .DS. 'payment_sn_k2store' .DS. 'libraries' .DS;
        $to = JPATH_ROOT .DS. 'libraries' .DS;
        JFolder::copy($from,$to,'',true);

        if(JFolder::exists($from))
        {
            JFolder::delete($from);
        }
    }

    function uninstall($parent)
    {

    }
}